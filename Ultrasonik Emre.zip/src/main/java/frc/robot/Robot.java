package frc.robot;

import com.ctre.phoenix.motorcontrol.can.WPI_VictorSPX;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.TimedRobot;
import edu.wpi.first.wpilibj.Ultrasonic;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.math.controller.PIDController;
import edu.wpi.first.math.filter.MedianFilter;

public class Robot extends TimedRobot {

  private final WPI_VictorSPX driveLeftA = new WPI_VictorSPX(1);
  private final WPI_VictorSPX driveLeftB = new WPI_VictorSPX(2);
  private final WPI_VictorSPX driveRightA = new WPI_VictorSPX(3);
  private final WPI_VictorSPX driveRightB = new WPI_VictorSPX(4);
  private final Joystick joy1 = new Joystick(0);
  static final double kHoldDistanceCentimeters = 30;
  private static final double kP = -0.001;
  private static final double kI = 0.0;
  private static final double kD = 0.0;
  static final int kLeftMotorPort = 0;
  static final int kRightMotorPort = 1;
  static final int kUltrasonicPingPort = 0;
  static final int kUltrasonicEchoPort = 1;
  private final MedianFilter m_filter = new MedianFilter(5);
  private Ultrasonic m_ultrasonic;
  private final WPI_VictorSPX m_leftMotor = new WPI_VictorSPX(kLeftMotorPort);
  private final WPI_VictorSPX m_rightMotor = new WPI_VictorSPX(kRightMotorPort);
  private final DifferentialDrive m_robotDrive = new DifferentialDrive(m_leftMotor, m_rightMotor);
  private final PIDController m_pidController = new PIDController(kP, kI, kD);

  String resultColor;

  private double startTime;

  @Override
  public void robotInit() {
    m_ultrasonic = new Ultrasonic(kUltrasonicPingPort, kUltrasonicEchoPort); // Initialize m_ultrasonic
    m_ultrasonic.setEnabled(true); // Enable the ultrasonic sensor
  }

  @Override
  public void autonomousInit() {
    m_pidController.setSetpoint(kHoldDistanceCentimeters);
  }

  @Override
  public void autonomousPeriodic() {
    double measurement = m_ultrasonic.getRangeMM();
    double filteredMeasurement = m_filter.calculate(measurement);
    double pidOutput = m_pidController.calculate(filteredMeasurement);

    if (filteredMeasurement < kHoldDistanceCentimeters) {
        driveLeftA.set(0.5);
        driveLeftB.set(0.5);
        driveRightA.set(0.5);
        driveRightB.set(0.5);
    }
    else {
      driveLeftA.set(0.0);
      driveLeftB.set(0.0);
      driveRightA.set(0.5);
      driveRightB.set(0.5);
    }
  }

  @Override
  public void teleopInit() {
  }

  @Override
  public void teleopPeriodic() {
    double speed = -joy1.getRawAxis(1) * 0.6;
    double turn = joy1.getRawAxis(4) * 0.3;

    double left = speed + turn;
    double right = speed - turn;

    driveLeftA.set(left);
    driveLeftB.set(left);
    driveRightA.set(-right);
    driveRightB.set(-right);
  }

  @Override
  public void testInit() {
  }

  @Override
  public void testPeriodic() {
  }
}
